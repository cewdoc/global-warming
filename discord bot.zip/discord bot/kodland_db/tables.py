from sqlalchemy import Column, Integer, String
from .db import Base


class Users(Base):

    __tablename__ = 'users'

    id = Column(Integer, primary_key=True, index=True,  unique=True)
    discord_id = Column(String)
    language = Column(String)
